public class PrintDirs implements Command {
    public void printDirs(){
        System.out.println("impriendo Dirs");
    }
    @Override
    public void execute() {
        printDirs();
    }
}
