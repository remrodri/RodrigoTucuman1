import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Apply implements Command
{
    MyDir dir;
    List<File> dirs=new ArrayList<>();
    List<File> files = new ArrayList<>();
    Apply(MyDir dir){
        this.dir=dir;
        aux();
    }
    private void aux()
    {
        String pathWindows = "D:"+dir.getPath().replace("\"","").replace("/","\\");
        File dire = new File(pathWindows);
        applyJavac(dire);
    }
    private void applyJavac(File dire){
        //List<File> dirs=new ArrayList<>();
        //System.out.println("compilando javac");
        //System.out.println(pathWindows);
        //System.out.println(dire.isDirectory());
        File[] listFiles = dire.listFiles();
        for (File file:listFiles){
            System.out.println(file);
        }
//        assert listFiles != null;
        for (File file :
                listFiles) {
            //System.out.println(file);
            if (file.isDirectory()){
                dirs.add(file);
            }else{
                files.add(file);
            }
        }
        checkListFiles();
    }
    private void checkListFiles() {
        if(dirs.size()>0){
            for (File file :
                    dirs) {
                applyJavac(file);
            }
        }else{
            compile();
        }
    }
    private void compile(){
        for (File file :
                files) {
            System.out.println(file);
        }
    }
    @Override
    public void execute() {
        aux();
    }
}
