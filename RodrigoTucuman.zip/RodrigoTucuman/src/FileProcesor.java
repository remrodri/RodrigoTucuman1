import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class FileProcesor {
    private List<String> content = new ArrayList<>();
    private File ruta;
    private MyDir myDir;
    private File path;
    Tool tool;

    FileProcesor(File file) {
        ruta = new File(file,"bob.conf");
        path = file;
        //System.out.println(System.getProperty("os.name"));
        //System.out.println( File.separatorChar == '/' ? "Unix" : "Windows" );
        if (!(File.separatorChar == '/')){
            System.out.println("windows");
            procesarRuta();
        }
    }
    //public FileProcesor(){
    //    procesarRuta();
    //}
    private boolean existeRuta(){
        boolean flag;
        //System.out.println(ruta);
        flag = ruta.exists();
        return flag;
    }
    private void procesarRuta(){
        if (!existeRuta()){
            System.out.println("no existe esa ruta, se establecera el directorio actual como ruta por defecto");
            //ruta = new File(".","bob.conf");
            ruta = new File(".");
            System.out.println(ruta);
        }else{

            try {
                Scanner scannerContent = new Scanner(ruta);
                String line;
                while (scannerContent.hasNextLine()){
                    line = scannerContent.nextLine();
                    if(!line.equals("")){
                        //System.out.println(line);
                        content.add(line);
                    }
                }
                procesarContenido();
            }
            catch (FileNotFoundException e){
                System.out.println("Error");
                e.printStackTrace();
            }
        }
    }
    private void procesarContenido() {
        for (String line :
                content) {
            String[] fragmentedLine=line.split(" ");
            //System.out.println(fragmentedLine[0]);
                switch (fragmentedLine[0]){
                    case "dir": fragmentedLine = fragmentedLine[1].split("=");
                        crearDir(fragmentedLine[0],fragmentedLine[1]);
                        break;
                    case "print": if(fragmentedLine[1].equals(myDir.getName())){
                                    System.out.println(myDir.getPath());
                                    //ejecutarPrint();
                                    }else{if (fragmentedLine[1].equals(myDir.getName()+".files")){
                                            PrintFiles pf=new PrintFiles();
                                            pf.execute();
                                            }else{if (fragmentedLine[1].equals(myDir.getName()+".dirs")){
                                                    PrintDirs pd=new PrintDirs();
                                                    pd.execute();} }}

                        break;
                    case "tool": tool=new Tool(fragmentedLine[1],fragmentedLine[2],fragmentedLine[3],fragmentedLine[4]);
                    break;
                    case "apply": if(fragmentedLine[1].equals("javac")){
                        if(fragmentedLine[2].equals(myDir.getName()+".files")){
                            Apply a = new Apply(myDir);
                            a.execute();
                        }
                    }
                    break;

                    }
                }
        }


    private void ejecutarPrint() {
        PrintFiles pf=new PrintFiles();
        pf.execute();
    }

    private void crearDir(String nombre, String ruta) {
        myDir = new MyDir(nombre,ruta);
        //System.out.println(nombre + ruta);
    }
}
