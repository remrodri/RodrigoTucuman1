public class PrintFiles implements Command {
    public void printFiles() {
        System.out.println("imprimiendo files");
    }
    @Override
    public void execute() {
        printFiles();
    }
}
