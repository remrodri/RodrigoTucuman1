public class Tool {
    private String tipo;
    private String nombre;
    private String tipoNombre1;
    private String tipoNombre2;

    Tool(String tipo, String nombre, String tipoNombre1, String tipoNombre2) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.tipoNombre1 = tipoNombre1;
        this.tipoNombre2 = tipoNombre2;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public String getTipoNombre1() {
        return tipoNombre1;
    }

    public String getTipoNombre2() {
        return tipoNombre2;
    }
}
